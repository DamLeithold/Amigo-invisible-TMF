import { NextResponse } from "next/server";
import { db, FieldValue } from "../../../lib/firebaseAdmin";

async function getParticipantByCode(code) {
  const cleanCode = String(code || "").trim().toUpperCase();
  if (!cleanCode) return null;

  const snap = await db.collection("participants")
    .where("code", "==", cleanCode)
    .limit(1)
    .get();

  if (snap.empty) return null;

  const doc = snap.docs[0];
  return { id: doc.id, ...doc.data() };
}

export async function POST(request) {
  try {
    const { code, text } = await request.json();
    const participant = await getParticipantByCode(code);

    if (!participant) {
      return NextResponse.json({ error: "Código inválido." }, { status: 401 });
    }

    const clueText = String(text || "").trim();

    if (clueText.length < 5) {
      return NextResponse.json({ error: "La pista es muy corta." }, { status: 400 });
    }

    if (clueText.length > 300) {
      return NextResponse.json({ error: "La pista no puede superar 300 caracteres." }, { status: 400 });
    }

    await db.collection("clues").add({
      fromId: participant.id,
      toId: participant.assignedToId,
      text: clueText,
      createdAt: FieldValue.serverTimestamp()
    });

    return NextResponse.json({ ok: true });
  } catch (error) {
    return NextResponse.json({ error: "Error al enviar pista." }, { status: 500 });
  }
}
