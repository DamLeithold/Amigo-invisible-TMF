import { NextResponse } from "next/server";
import { db } from "../../../lib/firebaseAdmin";

export async function POST(request) {
  try {
    const { code } = await request.json();
    const cleanCode = String(code || "").trim().toUpperCase();

    if (!cleanCode) {
      return NextResponse.json({ error: "Ingresá tu código." }, { status: 400 });
    }

    const snap = await db.collection("participants")
      .where("code", "==", cleanCode)
      .limit(1)
      .get();

    if (snap.empty) {
      return NextResponse.json({ error: "Código inválido." }, { status: 401 });
    }

    const doc = snap.docs[0];
    const data = doc.data();

    return NextResponse.json({
      ok: true,
      code: cleanCode,
      participant: {
        id: doc.id,
        name: data.name
      }
    });
  } catch (error) {
    return NextResponse.json({ error: "Error al ingresar." }, { status: 500 });
  }
}
