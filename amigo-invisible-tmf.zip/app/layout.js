import "./globals.css";

export const metadata = {
  title: "Amigo Invisible TMF",
  description: "Portal de amigo invisible"
};

export default function RootLayout({ children }) {
  return (
    <html lang="es">
      <body>{children}</body>
    </html>
  );
}
