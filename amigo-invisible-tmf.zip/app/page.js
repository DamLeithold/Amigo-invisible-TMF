"use client";

import { useEffect, useState } from "react";

const eventName = process.env.NEXT_PUBLIC_EVENT_NAME || "Amigo Invisible TMF";
const eventDate = process.env.NEXT_PUBLIC_EVENT_DATE || "2026-07-23";

function daysLeft() {
  const today = new Date();
  const target = new Date(eventDate + "T00:00:00");
  const diff = target.getTime() - today.getTime();
  return Math.max(0, Math.ceil(diff / (1000 * 60 * 60 * 24)));
}

export default function Home() {
  const [code, setCode] = useState("");
  const [savedCode, setSavedCode] = useState("");
  const [loading, setLoading] = useState(false);
  const [participant, setParticipant] = useState(null);
  const [clues, setClues] = useState([]);
  const [clueText, setClueText] = useState("");
  const [message, setMessage] = useState("");
  const [revealed, setRevealed] = useState(false);

  async function loadData(activeCode) {
    setLoading(true);
    setMessage("");
    try {
      const res = await fetch("/api/me", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ code: activeCode })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "No se pudo cargar.");
      setParticipant(data.participant);
      setClues(data.clues || []);
      setSavedCode(activeCode);
      localStorage.setItem("amigoCode", activeCode);
    } catch (err) {
      setMessage(err.message);
      localStorage.removeItem("amigoCode");
    } finally {
      setLoading(false);
    }
  }

  async function login(e) {
    e.preventDefault();
    const clean = code.trim().toUpperCase();
    if (!clean) return;
    await loadData(clean);
  }

  async function sendClue(e) {
    e.preventDefault();
    setLoading(true);
    setMessage("");
    try {
      const res = await fetch("/api/clues", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ code: savedCode, text: clueText })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "No se pudo enviar.");
      setClueText("");
      setMessage("Pista enviada correctamente.");
      await loadData(savedCode);
    } catch (err) {
      setMessage(err.message);
    } finally {
      setLoading(false);
    }
  }

  function logout() {
    localStorage.removeItem("amigoCode");
    setSavedCode("");
    setParticipant(null);
    setClues([]);
    setCode("");
    setRevealed(false);
  }

  useEffect(() => {
    const existing = localStorage.getItem("amigoCode");
    if (existing) loadData(existing);
  }, []);

  if (!participant) {
    return (
      <main>
        <div className="card">
          <div className="logo">🎁</div>
          <h1>{eventName}</h1>
          <p className="muted">Ingresá tu código secreto para ver a quién te tocó y gestionar tus pistas.</p>

          <form onSubmit={login} className="grid">
            <input
              value={code}
              onChange={(e) => setCode(e.target.value.toUpperCase())}
              placeholder="Ejemplo: A7K9P2"
              autoFocus
            />
            <button disabled={loading}>{loading ? "Ingresando..." : "Ingresar"}</button>
          </form>

          {message && <p className="error">{message}</p>}
        </div>
      </main>
    );
  }

  return (
    <main>
      <div className="card">
        <div className="row">
          <div>
            <div className="logo">🎁</div>
            <h1>{eventName}</h1>
            <p className="muted">Hola, {participant.name}. Faltan {daysLeft()} días para el intercambio.</p>
          </div>
        </div>

        <div className="grid">
          <section className="section">
            <h2>🎯 Mi amigo invisible</h2>
            {!revealed ? (
              <>
                <p className="muted">Tocá el botón para revelar a quién tenés que regalarle.</p>
                <button onClick={() => setRevealed(true)}>Revelar mi amigo</button>
              </>
            ) : (
              <div className="friend">{participant.assignedToName}</div>
            )}
          </section>

          <section className="section">
            <h2>✉️ Enviar pista</h2>
            <p className="muted">Tu pista la va a ver tu amigo invisible, pero no sabrá que fuiste vos.</p>
            <form onSubmit={sendClue} className="grid">
              <textarea
                value={clueText}
                onChange={(e) => setClueText(e.target.value)}
                placeholder="Ejemplo: Compartimos muchas reuniones, pero casi nunca coincidimos en la oficina."
                maxLength={300}
              />
              <button disabled={loading}>{loading ? "Enviando..." : "Enviar pista"}</button>
            </form>
          </section>

          <section className="section">
            <h2>🕵️ Pistas que recibí</h2>
            {clues.length === 0 ? (
              <p className="muted">Todavía no recibiste pistas.</p>
            ) : (
              clues.map((clue) => (
                <div className="clue" key={clue.id}>
                  <strong>Pista {clue.number}</strong>
                  <p>{clue.text}</p>
                </div>
              ))
            )}
          </section>

          {message && (
            <p className={message.includes("correctamente") ? "success" : "error"}>{message}</p>
          )}

          <button className="secondary" onClick={logout}>Salir</button>
        </div>
      </div>
    </main>
  );
}
