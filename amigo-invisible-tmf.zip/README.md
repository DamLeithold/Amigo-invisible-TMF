# Amigo Invisible TMF

Portal simple para que cada participante:

- Ingrese con su código secreto.
- Vea a quién le tocó regalarle.
- Envíe pistas a su amigo invisible.
- Vea las pistas que recibió.
- No pueda ver la lista completa ni espiar a otros.

## 1. Crear proyecto en Firebase

1. Entrá a Firebase Console.
2. Creá un proyecto.
3. Activá Firestore Database.
4. En Project settings > Service accounts, generá una nueva private key.
5. Guardá los datos en las variables de entorno de Vercel.

## 2. Subir a Vercel

1. Subí esta carpeta a GitHub.
2. En Vercel, importá el repositorio.
3. Cargá estas variables de entorno:
   - FIREBASE_PROJECT_ID
   - FIREBASE_CLIENT_EMAIL
   - FIREBASE_PRIVATE_KEY
   - NEXT_PUBLIC_EVENT_DATE
   - NEXT_PUBLIC_EVENT_NAME

Importante: FIREBASE_PRIVATE_KEY debe conservar los `\n`.

## 3. Cargar participantes

Editá `scripts/seed.js` con los nombres de los participantes.

Después ejecutá:

```bash
npm install
npm run seed
```

Eso crea:
- Participantes.
- Códigos secretos.
- Sorteo automático.

En consola se imprimen los códigos para enviarle uno a cada participante.

## 4. Estructura en Firestore

Colección `participants`:

```js
{
  name: "Damian",
  code: "A7K9P2",
  assignedToId: "idDeFlor",
  assignedToName: "Flor",
  createdAt: Date
}
```

Colección `clues`:

```js
{
  fromId: "idDeDamian",
  toId: "idDeFlor",
  text: "Le gusta mucho el café",
  createdAt: Date
}
```

## 5. Seguridad

La app no usa Firebase en el navegador. Todo pasa por rutas API del servidor de Next.js con Firebase Admin.

El usuario solo puede consultar usando su código secreto. No hay pantalla para listar todos los participantes.
