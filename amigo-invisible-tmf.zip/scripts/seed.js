/*
  Editá la lista de participantes y ejecutá:

  npm install
  npm run seed

  Esto genera códigos secretos y asigna amigos invisibles evitando que alguien se toque a sí mismo.
*/

const admin = require("firebase-admin");

function getPrivateKey() {
  const key = process.env.FIREBASE_PRIVATE_KEY;
  if (!key) return undefined;
  return key.replace(/\\n/g, "\n");
}

admin.initializeApp({
  credential: admin.credential.cert({
    projectId: process.env.FIREBASE_PROJECT_ID,
    clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
    privateKey: getPrivateKey()
  })
});

const db = admin.firestore();

const participantes = [
  "Damian",
  "Flor",
  "Eliana",
  "Paola",
  "Diógenes"
  // Agregá todos los participantes acá
];

function code() {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let out = "";
  for (let i = 0; i < 6; i++) out += chars[Math.floor(Math.random() * chars.length)];
  return out;
}

function shuffle(array) {
  const arr = [...array];
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

function makeAssignments(names) {
  let assigned = shuffle(names);
  let attempts = 0;

  while (names.some((name, index) => name === assigned[index])) {
    assigned = shuffle(names);
    attempts++;
    if (attempts > 1000) throw new Error("No se pudo generar sorteo válido.");
  }

  return names.map((name, index) => ({
    name,
    assignedToName: assigned[index]
  }));
}

async function main() {
  if (participantes.length < 3) {
    throw new Error("Cargá al menos 3 participantes.");
  }

  const assignments = makeAssignments(participantes);

  const batch = db.batch();
  const refsByName = {};

  assignments.forEach((p) => {
    const ref = db.collection("participants").doc();
    refsByName[p.name] = ref;
  });

  assignments.forEach((p) => {
    batch.set(refsByName[p.name], {
      name: p.name,
      code: code(),
      assignedToId: refsByName[p.assignedToName].id,
      assignedToName: p.assignedToName,
      createdAt: admin.firestore.FieldValue.serverTimestamp()
    });
  });

  await batch.commit();

  console.log("\nCódigos para enviar a cada participante:\n");

  const snap = await db.collection("participants").get();
  snap.docs
    .map(doc => doc.data())
    .sort((a, b) => a.name.localeCompare(b.name))
    .forEach(p => {
      console.log(`${p.name}: ${p.code} | Le tocó: ${p.assignedToName}`);
    });

  console.log("\nListo.");
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
